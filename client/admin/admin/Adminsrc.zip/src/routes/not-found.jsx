export default function NotFound(){return <p>404 — No encontrado</p>}
