// Validation middleware
